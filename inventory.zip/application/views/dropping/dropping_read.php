<div class="content-wrapper">
    
<section class="content">
    <div class="box box-warning box-solid">
        <div class="box-header with-border">
            <h3 class="box-title">Dropping Read</h3>
        </div>
        
        
<table class='table table-bordered>'>
	    <tr><td>Kode M Kasir</td><td><?php echo $kode_m_kasir; ?></td></tr>
	    <tr><td>Kode Barang</td><td><?php echo $kode_barang; ?></td></tr>
	    <tr><td>Stok</td><td><?php echo $stok; ?></td></tr>
	    <tr><td>Datetime</td><td><?php echo $datetime; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('dropping') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>

</div>
</div>
</div>