<div class="content-wrapper">
    <section class="content">
        <?php echo alert('alert-info', 'Selamat Datang', 'Selamat Datang Di Halaman Utama') ?>
    </section>
</div>